import { Component, OnInit, EventEmitter, Output } from '@angular/core';
@Component({
  selector: 'app-template',
  templateUrl: './template.component.html',
  styleUrls: ['./template.component.css']
})
export class TemplateComponent implements OnInit {
  newServerName = '';
  newServerContent = '';
  @Output() serverCreated= new EventEmitter<{serverName : string, serverContent : string}>();
  @Output() bluePrintCreated= new EventEmitter<{serverName : string, serverContent : string}>();

  constructor() { }

  ngOnInit() {
  }
  onAddServer() {
    this.serverCreated.emit({serverName: this . newServerName, serverContent : this . newServerContent});


  }
  onAddBlueprint() {
    this.bluePrintCreated.emit({serverName: this . newServerName, serverContent : this . newServerContent});





  }

}
