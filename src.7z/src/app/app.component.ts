import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  serverElements = [{type: 'server', name: 'test server', content : 'for testing'}];

  onServerAdded(serverData: {serverName: string, serverContent : string}) {

     this.serverElements.push({
     type: 'server',
     name: serverData.serverName,
     content: serverData.serverContent
    });
  }

  onBlueprintAdded(bluePrintData: {name: string, content : string}) {
    this.serverElements.push({
     type: 'blueprint',
      name: bluePrintData.name,
     content: bluePrintData.content
     });
  }
}
